setwd("C:\\Users\\damin\\OneDrive\\Desktop\\IT24104287 Lab Sheet 10")
observed <- c(55, 62, 43, 46, 50)
prob <- c(.2,.2, .2, .2,.2)


chisq.test(x=observed, p=prob)

file_path <- "http://www.sthda.com/sthda/RDoc/data/housetasks.txt" 
housetasks <- read.delim (file_path, row.names = 1)
housetasks

chisq <-chisq.test(housetasks)
chisq


#Exercise

#01
#Null hypothesis (H₀): 
#Customers choose the four snack types (A, B, C, D) 
#with equal probability (i.e., the observed purchases fit a uniform distribution).


#Alternative hypothesis (H₁): 
#Customers do not choose the four snack types with equal probability (i.e., the distribution is not uniform).

#02
# Observed purchase counts
observed_snacks <- c(120, 95, 85, 100)

# Perform Chi-squared goodness-of-fit test
chisq.test(observed_snacks)

#03
#At a significance level of 0.05, the p-value (0.090) is greater than 0.05. 
#Therefore, we fail to reject the null hypothesis. 
#There is not enough evidence to suggest that customers choose the snack types with unequal probabilities. 
#The vending machine owner's claim is supported by the data

