getwd()

print(sample(1:3))
print(sample(1:3,size=3,replace=FALSE))
print(sample(c(2,5,3),size=4,replace=TRUE))
print(sample(c(2,5,3),size=4,replace=FALSE))
print(sample(1:2,size=10,prob=c(0.3,0.7),replace=TRUE))
sample(1:3)
sample(1:3,size=3,replace=FALSE)
sample(c(2,5,3),size=4,replace=TRUE)
sample(c(2,5,3),size=4,replace=FALSE)
sample(1:2,size=10,prob=c(0.3,0.7),replace=TRUE)

#If condition
x<-1:10
m<-sample(x,1)
if (m <= 5) {
  print("m is less than 5")
}

#If Else condition
x<-1:10
y<-sample(x,1)
if (y <= 5) {
  print("y is less than 5")
} else{
  print("y is greater than 5")
}
yy<-sample(x,1)
if (yy<10) {
  z<-5
} else{
  z<-0
}

z

#Nested If Condition
xx<-sample(-5:8,1)
if (xx<0) {
  print("Negative Number")
} else if (xx>0) {
  print("Positive Number")
} else{
  print("Zero")
}

#For Loops
for (i in 1:15) {
  print(i)
}

#This loop runs from i = 1 to 15 and print the value
student<-c("Ann", "Steave", "Kyle", "John")
for (i in 1:4) {
  print(student [i])
}
for (i in 1:3) {
  print(student [i])
}
for (i in 1:6) {
  print (student [i])
}

#while Loop
j <- 1
while(j < 10){
  print(j)
  j <- j + 1
}
k <- 5
while (k < 10){
  print(k)
  k <- k + 1
}
m <- 2.987
while (m <= 4.987){
  m <- m + 0.987
  print(c(m,m-2,m-1))
}

#Functions
h <- 1
aaa=function(r) {
  h<<- h + 1
  r<-h+r
  print(r)
}
aaa (3)


data1<-read.table("Data1.txt", header=TRUE, sep=",")
data1
data2<-read.csv("DATA 2.csv", header=TRUE)
data2
fix(data2)

#Exporting Data Frames
height<-c(12,23,56)
weight<-c(45,78,89)
sheep<-data.frame (height, weight)
fix (sheep)
write.csv(sheep, file="SheepNew.csv")
write.table(sheep, file="Sheeptabl.txt")

#Exercise

#01
x<-c(1,2,3)
x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]

#02
x <- 1:15
sum(x %% 3 == 0)

#03
x <- c(5, 9, 3, 12, 7, 12)
max_index <- 1
for (i in 2:length(x)) {
  if (x[i] > x[max_index]) {
    max_index <- i
  }
}
max_index

#04
x <- c(5, 9, 3, 12, 7, 12)
which.max(x)
